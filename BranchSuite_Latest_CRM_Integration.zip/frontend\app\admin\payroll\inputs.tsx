// import { AdminBottomNavigation } from '../../../src/ui/AdminBottomNavigation';
// import { useAdminLayout } from '../../../src/ui/useAdminLayout';
// import React, { useCallback, useRef, useState } from 'react';
// import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
// import AsyncStorage from '../../../src/core/admin/storage';
// import { ActivityIndicator, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
// import { SafeAreaView } from 'react-native-safe-area-context';
// import { getEmployees, type Employee } from '../../../src/core/employees';
// import { readPayroll, savePayroll, type PayrollRecord } from '../../../src/core/payroll';

// type Shift = { id: string; employeeId: string; date: string; checkIn: string; checkOut: string; branch?: string; needsReview?: boolean };
// const shiftKey = 'branchsuite:team-attendance:v1';
// const currentMonth = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date()).slice(0, 7);
// const money = (value: number) => `₹${value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;

// export default function PayrollInputsPage() {
//   const { styles } = useAdminLayout(baseStyles, 'page');
//   const router = useRouter();
//   const params = useLocalSearchParams<{ branch?: string; period?: string }>();
//   const [branch, setBranch] = useState(typeof params.branch === 'string' ? params.branch : '');
//   const period = typeof params.period === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(params.period) ? params.period : currentMonth();
//   const [employees, setEmployees] = useState<Employee[]>([]);
//   const [records, setRecords] = useState<PayrollRecord[]>([]);
//   const [shifts, setShifts] = useState<Shift[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState('');
//   const [attempt, setAttempt] = useState(0);
//   const [picker, setPicker] = useState(false);
//   const [editing, setEditing] = useState<Employee | null>(null);
//   const [gross, setGross] = useState('');
//   const [deductions, setDeductions] = useState('');
//   const [incentives, setIncentives] = useState('');
//   const [saving, setSaving] = useState(false);
//   const [saveError, setSaveError] = useState('');
//   const [notice, setNotice] = useState('');
//   const savingRef = useRef(false);

//   useFocusEffect(useCallback(() => {
//     let active = true;
//     setLoading(true); setError('');
//     Promise.all([getEmployees(), readPayroll(), AsyncStorage.getItem(shiftKey)]).then(([team, pay, stored]) => {
//       const attendance: unknown = stored === null ? [] : JSON.parse(stored);
//       if (!Array.isArray(attendance) || !attendance.every(item => item && ['id', 'employeeId', 'date', 'checkIn', 'checkOut'].every(key => typeof item[key] === 'string'))) throw new Error('Attendance records could not be read.');
//       if (active) { setEmployees(team); setRecords(pay); setShifts(attendance); }
//     }).catch(reason => { if (active) setError(reason instanceof Error ? reason.message : 'Could not load payroll inputs.'); }).finally(() => { if (active) setLoading(false); });
//     return () => { active = false; };
//   }, [attempt]));

//   const branches = [...new Set(employees.map(employee => employee.branch).filter(Boolean))].sort();
//   const team = employees.filter(employee => employee.status !== 'inactive' && (!branch || employee.branch === branch));
//   const payrollFor = (employee: Employee) => records.find(record => record.employeeId === employee.id && record.period === period && (!branch || (record.branch || employee.branch) === branch));
//   const inputChecks = team.filter(employee => { const record = payrollFor(employee); return !record || record.gross < 0 || record.deductions < 0 || record.deductions > record.gross || (record.incentives || 0) < 0 || (record.incentives || 0) > record.gross; });
//   const attendanceChecks = shifts.filter(shift => shift.needsReview && shift.date.slice(0, 7) === period && team.some(employee => employee.id === shift.employeeId) && (!branch || (shift.branch || employees.find(employee => employee.id === shift.employeeId)?.branch) === branch));
//   const periodLabel = new Date(`${period}-01T12:00:00+05:30`).toLocaleDateString('en-GB', { timeZone: 'Asia/Kolkata', month: 'long', year: 'numeric' });
//   const back = () => router.replace({ pathname: '/admin/payroll', params: { branch, period } });
//   const edit = (employee: Employee) => { const record = payrollFor(employee); setEditing(employee); setGross(record ? String(record.gross) : ''); setDeductions(record ? String(record.deductions) : ''); setIncentives(record ? String(record.incentives || 0) : ''); setSaveError(''); };
//   const save = async () => {
//     if (!editing || savingRef.current) return;
//     setSaveError('');
//     if (!/^\d+(\.\d{1,2})?$/.test(gross.trim()) || !/^\d+(\.\d{1,2})?$/.test(deductions.trim()) || (incentives.trim() !== '' && !/^\d+(\.\d{1,2})?$/.test(incentives.trim()))) { setSaveError('Enter gross and deductions as non-negative amounts with up to two decimal places.'); return; }
//     savingRef.current = true; setSaving(true);
//     try {
//       const updated = await savePayroll({ employeeId: editing.id, employeeName: editing.fullName, branch: editing.branch, period, gross: Number(gross), deductions: Number(deductions), incentives: Number(incentives || 0) });
//       setRecords(updated); setEditing(null); setNotice('Payroll inputs saved on this device.');
//     } catch (reason) { setSaveError(reason instanceof Error ? reason.message : 'Could not save payroll inputs.'); }
//     finally { savingRef.current = false; setSaving(false); }
//   };

//   return <SafeAreaView style={styles.safe}><View style={styles.page}>
//     <View style={styles.header}><View style={[styles.row, styles.headerIdentity]}><View style={styles.flex}><Text style={styles.companyName}>{/* Your company name */}</Text><Text style={styles.small}>Business workspace</Text></View><View style={styles.headerIcon}><Text style={styles.chevron}>⌕</Text></View><View style={styles.avatar} /></View><View style={styles.headerFilters}><View style={styles.headerFilter}><Text style={styles.small}>Company</Text><Text style={styles.chevron}>⌄</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Choose branch" onPress={() => setPicker(true)} style={[styles.headerFilter, styles.blue]}><Text numberOfLines={1} style={[styles.small, styles.flex]}>{branch || 'All branches'}</Text><Text style={styles.chevron}>⌄</Text></Pressable></View></View>
//     <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
//       <View style={styles.row}><Pressable accessibilityRole="button" accessibilityLabel="Back to Payroll" onPress={back} style={styles.back}><Text style={styles.chevron}>‹</Text></Pressable><View style={styles.flex}><Text style={styles.eyebrow}>WORKSPACE</Text><Text style={styles.title}>Branch payroll inputs</Text><Text style={styles.subtitle}>{branch || 'All branches'} · {periodLabel}</Text></View></View>
//       <View style={styles.branchCard}><View style={styles.dot} /><View style={styles.flex}><Text style={styles.name}>{branch || 'All branches'}</Text><Text style={styles.small}>One branch, every module</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Change branch" onPress={() => setPicker(true)} style={styles.change}><Text style={styles.link}>Change</Text></Pressable></View>
//       <View style={styles.tip}><Text style={styles.tipText}>ⓘ  Resolve attendance and branch checks, then verify branch employee earnings.</Text></View>
//       {loading ? <ActivityIndicator accessibilityLabel="Loading payroll inputs" color="#345cf2" style={styles.change} /> : error ? <View style={styles.checkCard}><Text style={styles.error}>{error}</Text><Pressable accessibilityRole="button" onPress={() => setAttempt(value => value + 1)} style={styles.change}><Text style={styles.link}>Retry</Text></Pressable></View> : <>
//         <Text style={styles.sectionTitle}>Pre-payroll checks</Text><View style={styles.recordGrid}>
//         {attendanceChecks.map(shift => <View key={shift.id} style={[styles.checkCard, styles.responsiveRecordCard]}><View style={styles.row}><Text style={[styles.name, styles.flex]}>{employees.find(employee => employee.id === shift.employeeId)?.fullName || shift.employeeId}</Text><View style={styles.statusBadge}><Text style={styles.small}>Attendance</Text></View></View><Text style={styles.checkDescription}>Attendance confirmation required for {shift.date}</Text><Pressable accessibilityRole="button" accessibilityLabel={`Review attendance ${shift.id}`} onPress={() => router.push({ pathname: '/admin/attendance/team', params: { branch } })} style={styles.resolve}><Text style={styles.buttonText}>Review attendance check</Text></Pressable></View>)}
//         {inputChecks.map(employee => <View key={employee.id} style={[styles.checkCard, styles.responsiveRecordCard]}><View style={styles.row}><Text style={[styles.name, styles.flex]}>{employee.fullName}</Text><View style={styles.statusBadge}><Text style={styles.small}>Payroll</Text></View></View><Text style={styles.checkDescription}>{payrollFor(employee) ? 'Verify gross earnings, deductions and incentives.' : 'Employee payroll inputs are missing for this period.'}</Text><Pressable accessibilityRole="button" accessibilityLabel={`Resolve payroll check ${employee.fullName}`} onPress={() => edit(employee)} style={styles.resolve}><Text style={styles.buttonText}>Resolve check</Text></Pressable></View>)}
//         {attendanceChecks.length + inputChecks.length === 0 && <View style={styles.checkCard}><Text style={styles.name}>{team.length ? 'No checks to resolve' : 'No employees in this branch'}</Text><Text style={styles.subtitle}>{team.length ? 'Verify the saved employee earnings below.' : 'Your employees and payroll checks will appear here.'}</Text></View>}
//         </View><Text style={styles.sectionTitle}>Employee earnings</Text><View style={styles.recordGrid}>{team.map(employee => { const record = payrollFor(employee); return <View key={employee.id} style={[styles.checkCard, styles.responsiveRecordCard]}><View style={styles.row}><View style={styles.flex}><Text style={styles.name}>{employee.fullName}</Text><Text style={styles.subtitle}>{[employee.branch, employee.department].filter(Boolean).join(' · ')}</Text></View><Pressable accessibilityRole="button" accessibilityLabel={`Edit payroll ${employee.fullName}`} onPress={() => edit(employee)} style={styles.change}><Text style={styles.link}>{record ? 'Edit' : 'Add inputs'}</Text></Pressable></View><Text style={styles.subtitle}>Gross {record ? money(record.gross) : '—'} · Deductions {record ? money(record.deductions) : '—'}</Text><Text style={styles.name}>Net {record ? money(record.gross - record.deductions) : '—'}</Text></View>; })}</View>{notice !== '' && <Text accessibilityLiveRegion="polite" style={styles.notice}>{notice}</Text>}
//       </>}
//     </ScrollView>
//     <AdminBottomNavigation />
//   </View><Modal transparent visible={picker} animationType="fade" onRequestClose={() => setPicker(false)}><View style={styles.overlay}><View style={styles.modal}><View style={styles.row}><Text style={styles.modalTitle}>Choose branch</Text><Pressable accessibilityRole="button" accessibilityLabel="Close branch picker" onPress={() => setPicker(false)} style={styles.close}><Text style={styles.chevron}>×</Text></Pressable></View><ScrollView>{['', ...branches].map(value => <Pressable key={value} accessibilityRole="button" accessibilityLabel={value || 'All branches'} onPress={() => { setBranch(value); router.setParams({ branch: value }); setPicker(false); }} style={styles.option}><Text style={styles.name}>{value || 'All branches'}</Text><Text style={styles.link}>{branch === value ? '✓' : ''}</Text></Pressable>)}</ScrollView></View></View></Modal>
//     <Modal transparent visible={editing !== null} animationType="fade" onRequestClose={() => { if (!saving) setEditing(null); }}><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.overlay}><View style={styles.modal}><View style={styles.row}><Text style={styles.modalTitle}>{editing?.fullName}</Text><Pressable accessibilityRole="button" accessibilityLabel="Close earnings editor" disabled={saving} onPress={() => setEditing(null)} style={styles.close}><Text style={styles.chevron}>×</Text></Pressable></View><ScrollView keyboardShouldPersistTaps="handled"><Text style={styles.subtitle}>{periodLabel}</Text>{[{ label: 'Gross earnings', value: gross, change: setGross }, { label: 'Deductions', value: deductions, change: setDeductions }, { label: 'Sales incentives', value: incentives, change: setIncentives }].map(field => <View key={field.label}><Text style={styles.inputLabel}>{field.label} (INR)</Text><TextInput accessibilityLabel={field.label} value={field.value} onChangeText={field.change} editable={!saving} keyboardType="decimal-pad" style={styles.input} /></View>)}<Text style={styles.subtitle}>Include incentives in gross earnings once.</Text>{saveError !== '' && <Text accessibilityLiveRegion="polite" style={styles.error}>{saveError}</Text>}<Pressable accessibilityRole="button" disabled={saving} onPress={() => void save()} style={[styles.submit, styles.saveButton, saving && styles.dim]}><Text style={styles.submitText}>{saving ? 'Saving…' : 'Save inputs'}</Text></Pressable></ScrollView></View></KeyboardAvoidingView></Modal>
//   </SafeAreaView>;
// }

// const baseStyles = StyleSheet.create({
//   recordGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
//   back: { width: 36, height: 36, borderRadius: 10, borderWidth: 1, borderColor: '#e4eaf5', backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' }, tip: { backgroundColor: '#fff4e2', borderRadius: 16, padding: 16, marginTop: 16 }, tipText: { fontSize: 11, lineHeight: 18, color: '#98661e' }, sectionTitle: { marginTop: 22, marginBottom: 12, fontSize: 16, fontWeight: '700', color: '#20334f' }, checkCard: { marginBottom: 12, padding: 16, borderWidth: 1, borderColor: '#e0e8f5', borderRadius: 17, backgroundColor: '#fff' }, checkDescription: { fontSize: 12, lineHeight: 20, color: '#7a8ba5', marginTop: 16 }, resolve: { marginTop: 14, minHeight: 44, borderRadius: 12, borderWidth: 1, borderColor: '#dce5f3', alignItems: 'center', justifyContent: 'center' }, buttonText: { fontSize: 11, fontWeight: '600', color: '#405573' }, inputLabel: { fontSize: 12, fontWeight: '600', color: '#405573', marginTop: 16, marginBottom: 8 }, input: { minHeight: 46, paddingHorizontal: 13, borderRadius: 12, borderWidth: 1, borderColor: '#dce5f3', backgroundColor: '#fcfdff', fontSize: 14, color: '#20334f' }, saveButton: { marginTop: 20 }, safe: { flex: 1, backgroundColor: '#f6f8fd' }, page: { flex: 1, width: '100%', maxWidth: 560, alignSelf: 'center' }, flex: { flex: 1 }, row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 9 }, header: { padding: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#e4eaf5' }, companyName: { minHeight: 18, fontSize: 14, fontWeight: '800', color: '#20334f' }, small: { fontSize: 9, lineHeight: 16, color: '#8192ad' }, headerIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#f5f7fc' }, avatar: { width: 34, height: 34, borderRadius: 12, backgroundColor: '#eaf0ff' }, headerFilters: { flexDirection: 'row', gap: 8, marginTop: 14 }, headerFilter: { flex: 1, minHeight: 34, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 10, borderRadius: 9, borderWidth: 1, borderColor: '#e4eaf7', backgroundColor: '#f7f9ff' }, chevron: { fontSize: 23, color: '#607591' }, blue: { backgroundColor: '#eaf0ff', borderColor: '#d5dfff' }, content: { padding: 16, paddingTop: 24, paddingBottom: 28 }, eyebrow: { fontSize: 8, fontWeight: '700', letterSpacing: 2, color: '#8192ad' }, title: { fontSize: 25, fontWeight: '800', color: '#20334f', marginTop: 10, letterSpacing: -0.7 }, subtitle: { fontSize: 11, lineHeight: 18, color: '#7a8ba5', marginTop: 5 }, period: { minHeight: 32, justifyContent: 'center' }, branchCard: { flexDirection: 'row', alignItems: 'center', gap: 9, padding: 12, borderWidth: 1, borderColor: '#e4eaf5', borderRadius: 17, backgroundColor: '#fff', marginTop: 14 }, dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#39b8a7' }, name: { fontSize: 12, fontWeight: '700', color: '#20334f' }, change: { minHeight: 44, paddingHorizontal: 8, justifyContent: 'center' }, link: { fontSize: 10, fontWeight: '600', color: '#345cf2' }, steps: { flexDirection: 'row', marginVertical: 16 }, step: { flex: 1, alignItems: 'center', gap: 6 }, stepCircle: { width: 25, height: 25, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: '#e7edf7' }, activeStep: { backgroundColor: '#345cf2' }, stepNumber: { fontSize: 10, color: '#7a8ba5', fontWeight: '600' }, white: { color: '#fff' }, stepLabel: { fontSize: 9, color: '#607591' }, runCard: { padding: 20, borderRadius: 20, backgroundColor: '#eeedfc', borderWidth: 1, borderColor: '#e2e6fc', marginBottom: 16 }, runLabel: { fontSize: 9, fontWeight: '700', letterSpacing: 1, color: '#345cf2' }, statusBadge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4, backgroundColor: '#fff1d9' }, net: { fontSize: 32, fontWeight: '800', color: '#20334f', marginTop: 16 }, grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 16 }, metric: { width: '46%', flexGrow: 1, padding: 14, backgroundColor: '#fff', borderWidth: 1, borderColor: '#e0e8f5', borderRadius: 16 }, metricLabel: { fontSize: 10, color: '#607591' }, metricValue: { fontSize: 22, fontWeight: '800', color: '#20334f', marginVertical: 7 }, workspace: { width: '46%', flexGrow: 1, borderWidth: 1, borderColor: '#e0e8f5', borderRadius: 18, backgroundColor: '#fff', overflow: 'hidden' }, workspaceBody: { padding: 14, minHeight: 144 }, icon: { width: 36, height: 36, borderRadius: 12, justifyContent: 'center', alignItems: 'center' }, glyph: { fontSize: 23 }, countBadge: { borderRadius: 7, paddingHorizontal: 8, paddingVertical: 5, backgroundColor: '#f2f5fc' }, workspaceTitle: { fontSize: 13, fontWeight: '700', color: '#20334f', marginTop: 14 }, workspaceFooter: { minHeight: 36, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: '#f0f3f9', backgroundColor: '#fcfdff' }, submit: { minHeight: 46, borderRadius: 13, backgroundColor: '#345cf2', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12 }, submitText: { fontSize: 12, fontWeight: '700', color: '#fff' }, dim: { opacity: 0.5 }, notice: { marginTop: 12, fontSize: 12, color: '#34856c' }, error: { marginTop: 12, fontSize: 12, color: '#b94d61' }, errorBox: { padding: 14, borderRadius: 13, backgroundColor: '#fff', marginBottom: 12 }, navigation: { flexDirection: 'row', paddingVertical: 8, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e4eaf5' }, navItem: { flex: 1, alignItems: 'center', gap: 3 }, navIcon: { width: 46, height: 32, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, navGlyph: { fontSize: 22, color: '#71829c' }, navLabel: { fontSize: 9, color: '#71829c' }, overlay: { flex: 1, padding: 24, justifyContent: 'center', backgroundColor: 'rgba(27,43,68,0.3)' }, modal: { padding: 22, width: '100%', maxWidth: 460, maxHeight: '85%', alignSelf: 'center', borderRadius: 20, backgroundColor: '#fff' }, modalTitle: { flex: 1, fontSize: 18, fontWeight: '700', color: '#20334f' }, close: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center' }, option: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 17, borderBottomWidth: 1, borderBottomColor: '#edf1f8' }, detail: { paddingTop: 16 }, detailRow: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#edf1f8' },
// });



import React from 'react';
import {
  Redirect,
  useLocalSearchParams,
} from 'expo-router';

/**
 * BranchSuite Business — Payroll Inputs
 *
 * This route preserves compatibility with existing navigation
 * links to /admin/payroll/inputs.
 *
 * The full Payroll Inputs editor is implemented in:
 * frontend/app/admin/payroll/index.tsx
 *
 * Canonical route:
 * /admin/payroll?view=inputs
 *
 * This prevents duplicate form logic, inconsistent attendance
 * checks, and different salary-revision behavior between routes.
 */
export default function PayrollInputsPage() {
  const params = useLocalSearchParams<{
    branch?: string;
    period?: string;
  }>();

  const branch =
    typeof params.branch === 'string'
      ? params.branch
      : '';

  const period =
    typeof params.period === 'string' &&
    /^\d{4}-(0[1-9]|1[0-2])$/.test(params.period)
      ? params.period
      : undefined;

  return (
    <Redirect
      href={{
        pathname: '/admin/payroll',
        params: {
          view: 'inputs',
          branch,
          ...(period ? { period } : {}),
        },
      }}
    />
  );
}
