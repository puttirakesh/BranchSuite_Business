# Implementation notes

The original ZIP directories and files are retained, including its source and test trees that were missing from the initial working copy. `app/_layout.tsx` owns one persistent embedded workspace through `src/core/providers/AppProviders.tsx`. Group layouts render slots; feature screens select original APK screens or open their editors. Browser URLs follow APK navigation where a corresponding route exists. The mobile More menu remains an internal APK screen. The host publishes the current account into the shared auth context. TypeScript local collection readers access persisted snapshots without inventing remote endpoints.

`docs/build-reference.cjs` bundles the readable assets into a generated TypeScript document with no runtime fetches. The APK's complete PDF library is included before application startup. Small integration changes publish navigation, add plan creation, and preserve the rest of the original logic. `assets/responsive.css` augments the original responsive styles.

Validation: regenerate the reference, typecheck, export web, then exercise both roles, plan/offer editing, support replies and persistence in a browser at narrow, tablet and desktop widths. Native Android/iOS build, file sharing, hardware back behavior and device rotation need device/emulator verification before release.
