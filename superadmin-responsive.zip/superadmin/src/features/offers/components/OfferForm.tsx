import { BranchSuiteScreen } from '../../../core/providers/AppProviders';
export default function Form({ id }: { id?: string }) { return <BranchSuiteScreen route="platform-offers" action={id ? 'saas-offer-edit' : 'saas-offer-new'} id={id} />; }
