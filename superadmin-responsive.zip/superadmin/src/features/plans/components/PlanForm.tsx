import { BranchSuiteScreen } from '../../../core/providers/AppProviders';
export default function Form({ id }: { id?: string }) { return <BranchSuiteScreen route="platform-plans" action={id ? 'saas-edit-plan' : 'saas-plan-new'} id={id} />; }
