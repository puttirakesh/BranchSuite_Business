import { View, type ViewProps } from 'react-native';
import { colors } from '../../ui/theme';
export default function AppCard(props: ViewProps) { return <View {...props} style={[{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 18, padding: 20, gap: 8 }, props.style]} />; }
