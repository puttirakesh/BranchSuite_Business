export { default } from '../../../src/features/audit/screens/AuditHistoryScreen';
