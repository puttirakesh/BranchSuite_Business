export { default } from '../../../src/features/marketing/screens/MarketingScreen';
