export { default } from '../../../src/features/offers/screens/OfferDetailsScreen';
