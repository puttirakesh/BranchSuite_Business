import { BranchSuiteScreen } from '../../../assets/branchsuite';

export default function Screen() {
  return <BranchSuiteScreen route={'platform-plans'} action="saas-plan-new" />;
}
