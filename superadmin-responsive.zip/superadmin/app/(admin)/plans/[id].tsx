export { default } from '../../../src/features/plans/screens/PlanDetailsScreen';
